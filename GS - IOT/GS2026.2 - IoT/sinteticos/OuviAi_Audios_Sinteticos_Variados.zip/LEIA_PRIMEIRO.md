# OuviAí · Lote de áudio sintético

O lote contém **41 WAVs de base e 72 variações**, totalizando 113 arquivos de 5 segundos em PCM16 mono, 16 kHz. Cada arquivo deriva de um dos 41 MP3 gerados no ElevenLabs.

- `base_candidata/` contém 12 campainhas, 5 batidas na porta e 14 ambientes segundo os nomes dos arquivos. Os rótulos são provisórios e pedem conferência por escuta.
- `revisar_porta/` contém 10 sons cujo nome indica fechamento de porta ou deixa a ação indefinida. Se o áudio tiver apenas fechamento ou rangido, é candidato a `ambiente`. Se houver batidas de uma pessoa na porta, pode ser candidato a `batida_porta`.
- `variacoes/campainha/` contém oito variações para cada uma das quatro campainhas sem indicação de volume baixo ou ruído no nome.
- `variacoes/batida_porta/` contém oito variações para cada um dos cinco sons identificados como batidas. O ganho de base reserva margem para o aumento de 3 dB.
- `manifesto.csv` vincula cada WAV a seu MP3 de origem e registra preparo, ganhos, SNR e fundo utilizado.

## Variações

- volume_menos_6_db. Redução de 6 dB.
- volume_menos_12_db. Redução de 12 dB.
- volume_mais_3_db. Aumento de 3 dB.
- ventilador_snr_20_db. Mistura com ventilador a 20 dB de SNR.
- ventilador_snr_10_db. Mistura com ventilador a 10 dB de SNR.
- volume_menos_12_db_fundo_fixo. Evento 12 dB mais baixo com o mesmo fundo da variante a 20 dB de SNR.
- evento_atrasado. Deslocamento do sinal para mais tarde na janela de 5 s.
- reflexoes_leves. Simulação simples de reflexões do som num cômodo.

A SNR é medida sobre os 5 segundos, no mesmo intervalo usado na bateria anterior. O ruído é um ventilador do lote sintético. Na comparação com fundo fixo, a atenuação de 12 dB do sinal reduz a SNR de 20 para 8 dB com o fundo no mesmo nível. A perda de energia ao deslocar o sinal ficou abaixo de 2% da janela de referência. Nas batidas, o sinal pode ser adiantado ou atrasado para preservar eventos próximos às bordas. Os deslocamentos devem ser ouvidos antes do treino. As reflexões são um efeito simples e o ganho representa nível de sinal, sem correspondência direta com uma distância em metros.

## Uso na avaliação

Confirme primeiro os rótulos, os eventos dos recortes e os fundos. Compare a configuração 08 com a mesma base de avaliação pública usada antes. Ao selecionar dados de treino, mantenha cada original, seus derivados e os fundos usados nas misturas no mesmo conjunto. Registre a origem como sintética no manifesto. 
